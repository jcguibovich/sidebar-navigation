# Core Handlebars Helpers


## Usage

```
npm install --save-dev cxd-hbs-helpers.git
```

### Using vanilla Handlebars
```js
var helpers = require('cxd-hbs-helpers');
var Handlebars = require('handlebars');

helpers.forEach(function (helper) {
  Handlebars.registerHelper(helper.name, helper);
});
```

### Using `gulp-compile-handlebars`
```js
var gulp = require('gulp');
var handlebars = require('gulp-compile-handlebars');
var helpers = require('cxd-hbs-helpers');

gulp.task('default', function () {
  return gulp.src('*.hbs')
    .pipe(handlebars({
      helpers: helpers
    }))
    .pipe(gulp.dest('./dist'));
});
```

