'use strict';



var getFile = require('../').getFile;
var tape = require('tape');
var Handlebars = require('handlebars');


Handlebars.registerHelper(getFile.name, getFile);

tape('getFile', function (test) {
  var template = Handlebars.compile('{{getFile content}}');
  var expected;
  var actual;
  
  test.plan(2);

  expected = 'toc';
  actual = template({ content: 'docs/toc.md' });
  test.equal(actual, expected, 'Works with 1 directory');

  expected = 'toc-test';
  actual = template({ content: 'docs/toc-test.md' });
  test.equal(actual, expected, 'Works with slash in name');
});


