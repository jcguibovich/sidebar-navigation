'use strict';



var getExtName = require('../').getExtName;
var tape = require('tape');
var Handlebars = require('handlebars');


Handlebars.registerHelper(getExtName.name, getExtName);

tape('getExtName', function (test) {
  var template = Handlebars.compile('{{getExtName content}}');
  var expected;
  var actual;
  
  test.plan(2);

  expected = 'md';
  actual = template({ content: 'docs/toc.md' });
  test.equal(actual, expected, 'Works with single dot');

  expected = 'md';
  actual = template({ content: 'docs/toc.test.md' });
  test.equal(actual, expected, 'Works with double dot');
});


