'use strict';

var getDir = require('../').getDir;
var tape = require('tape');
var Handlebars = require('handlebars');


Handlebars.registerHelper(getDir.name, getDir);

tape('getDir', function (test) {
  var template = Handlebars.compile('{{getDir content}}');
  var expected;
  var actual;
  
  test.plan(3);

  expected = 'docs';
  actual = template({ content: 'docs/toc.md' });
  test.equal(actual, expected, 'Works with 1 directory');

  expected = 'to/docs';
  actual = template({ content: 'to/docs/toc.md' });
  test.equal(actual, expected, 'Works with 2 directory');

  expected = 'path/to/docs';
  actual = template({ content: 'path/to/docs/toc.md' });
  test.equal(actual, expected, 'Works with 3 directory');

});


