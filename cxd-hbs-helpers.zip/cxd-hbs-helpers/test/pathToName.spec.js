'use strict';

var pathToName = require('../').pathToName;
var tape = require('tape');
var Handlebars = require('handlebars');


Handlebars.registerHelper(pathToName.name, pathToName);

tape('pathToName', function (test) {
  var template = Handlebars.compile('{{pathToName content}}');
  var expected;
  var actual;
  
  test.plan(8);

  expected = 'toc';
  actual = template({ content: 'docs/toc.md' });
  test.equal(actual, expected, 'Works with 1 directory');

  expected = 'toc test';
  actual = template({ content: 'docs/toc-test.md' });
  test.equal(actual, expected, 'Works with dash in name');

  expected = 'toc test';
  actual = template({ content: 'path/to/docs/01 toc test.md' });
  test.equal(actual, expected, 'Works with number and spaces in name');

  expected = 'tic toc test';
  actual = template({ content: 'path/to/docs/01 tic-toc-test.md' });
  test.equal(actual, expected, 'Works with number and spaces in name');
 
  expected = 'tic toc test';
  actual = template({ content: 'path/to/docs/01_tic-toc-test.md' });
  test.equal(actual, expected, 'Works with number and underscore and dashes');

  expected = 'tic toc test';
  actual = template({ content: 'path/to/docs/01_tic_toc_test.md' });
  test.equal(actual, expected, 'Works with number and underscore in name');

  expected = 'tic toc test';
  actual = template({ content: 'path/to/docs/ tic_toc_test.md' });
  test.equal(actual, expected, 'Works with space in front');

  expected = 'tic toc test';
  actual = template({ content: 'path/to/docs/ _tic_toc_test.md' });
  test.equal(actual, expected, 'Works with underscore with space in front');
});


