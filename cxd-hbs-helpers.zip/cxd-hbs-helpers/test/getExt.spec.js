'use strict';



var getExt = require('../').getExt;
var tape = require('tape');
var Handlebars = require('handlebars');


Handlebars.registerHelper(getExt.name, getExt);

tape('getExt', function (test) {
  var template = Handlebars.compile('{{getExt content}}');
  var expected;
  var actual;
  
  test.plan(2);

  expected = '.md';
  actual = template({ content: 'docs/toc.md' });
  test.equal(actual, expected, 'Works with single dot');

  expected = '.md';
  actual = template({ content: 'docs/toc.test.md' });
  test.equal(actual, expected, 'Works with double dot');
});


