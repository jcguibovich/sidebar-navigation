'use strict';

var pathToTitle = require('../').pathToTitle;
var tape = require('tape');
var Handlebars = require('handlebars');


Handlebars.registerHelper(pathToTitle.name, pathToTitle);

tape('pathToTitle', function (test) {
  var template = Handlebars.compile('{{pathToTitle content}}');
  var expected;
  var actual;
  
  test.plan(8);

  expected = 'Toc';
  actual = template({ content: 'docs/toc.md' });
  test.equal(actual, expected, 'Works with 1 directory');

  expected = 'Toc Test';
  actual = template({ content: 'docs/toc-test.md' });
  test.equal(actual, expected, 'Works with dash in name');

  expected = 'Toc Test';
  actual = template({ content: 'path/to/docs/01 toc test.md' });
  test.equal(actual, expected, 'Works with number and spaces in name');

  expected = 'Tic Toc Test';
  actual = template({ content: 'path/to/docs/01 tic-toc-test.md' });
  test.equal(actual, expected, 'Works with number and spaces in name');
 
  expected = 'Tic Toc Test';
  actual = template({ content: 'path/to/docs/01_tic-toc-test.md' });
  test.equal(actual, expected, 'Works with number and underscore and dashes');

  expected = 'Tic Toc Test';
  actual = template({ content: 'path/to/docs/01_tic_toc_test.md' });
  test.equal(actual, expected, 'Works with number and underscore in name');

  expected = 'Tic Toc Test';
  actual = template({ content: 'path/to/docs/ tic_toc_test.md' });
  test.equal(actual, expected, 'Works with space in front');

  expected = 'Tic Toc Test';
  actual = template({ content: 'path/to/docs/ _tic_toc_test.md' });
  test.equal(actual, expected, 'Works with underscore with space in front');
});


